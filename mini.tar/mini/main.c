/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ahuanga <marvin@42fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/23 20:04:42 by ckulembe          #+#    #+#             */
/*   Updated: 2026/02/20 14:58:55 by ckulembe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int	ft_handler_pipe(char **prompt, t_list **tokens);

char	*value_token_type(t_token_type type)
{
	if (type == REDIR_IN)
		return ("<");
	else if (type == REDIR_OUT)
		return (">");
	else if (type == REDIR_APPEND)
		return (">>");
	else if (type == HEREDOC)
		return ("<<");
	return (NULL);
}

void	ft_varprint(void *var)
{
	if (!var)
		return ;
	printf("%s\n", (char *)var);
}

void	clean_all(char *message, t_list **tokens, t_list **cmds)
{
	if (tokens && *tokens)
		ft_lstclear(tokens, ft_tokenclear);
	if (cmds && *cmds)
		ft_lstclear(cmds, ft_cmdclear);
	if (message)
		free(message);
}

/*
 * Main para teste do funcionamento do parser
 */
int	main(int argc, char **argv, char **env)
{
	int		error;
	int		res;
	t_vars	*env_vars;
	char	*message;
	t_list	*tokens;
	t_list	*commands;

	signal(2, handler);
	signal(3, SIG_IGN);
	env_vars = ft_vars_update(env);
	env_vars->last_status = 0;
	while (1)
	{
		message = readline("minishell$ ");
		ft_historic(message);
		if ((error = ft_validate_quotes(message)))
		{
			clean_all(message, NULL, NULL);
			return (error);
		}
		tokens = ft_tokenize(message);
		if (!tokens)
			return (1);
		res = ft_check_syntax(tokens);
		if (res != 1)
		{
			if (res == 2 && !ft_handler_pipe(&message, &tokens))
				return (1);
			else if (res == 0)
				return (1);
		}
		ft_expasion(&tokens, &env_vars->last_status);
		commands = ft_parser(tokens);
		if (!commands)
			return (1);
		ft_lstiter(commands, ft_commandprint);
		clean_all(message, &tokens, &commands);
		windown_update(tokens);
	}
	ft_lstclear(&env_vars->lst_vars, lst_free);
	(void)argv;
	(void)argc;
	return (0);
}

int	ft_handler_pipe(char **prompt, t_list **tokens)
{
	char	*tmp;
	char	*pipe;

	while (1)
	{
		pipe = readline("pipe> ");
		if (pipe[0] == 0)
			continue ;
		tmp = ft_strjoin(*prompt, pipe);
		if (!tmp)
			return (0);
		free(*prompt);
		*prompt = tmp;
		ft_historic(*prompt);
		*tokens = ft_tokenize(*prompt);
		if (!ft_check_syntax(*tokens))
			return (0);
		break ;
	}
	return (1);
}
