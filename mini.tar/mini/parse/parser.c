/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parser.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckulembe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/04 18:33:37 by ckulembe          #+#    #+#             */
/*   Updated: 2026/02/09 11:21:45 by ckulembe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "parse.h"

static t_command	*ft_set_cmd(t_list **lst)
{
	size_t		length;
	t_command	*cmd;

	if (!lst || !*lst)
		return (NULL);
	cmd = (t_command *) malloc(sizeof(t_command));
	if (!cmd)
		return (NULL);
	cmd->args = NULL;
	cmd->redir = NULL;
	ft_word_count(*lst, &length);
	cmd->args = (char **) malloc (sizeof(char *) * (length + 1));
	if (!cmd->args)
		return (free(cmd), NULL);
	cmd->args[length] = NULL;
	return (cmd);
}

static t_command	*ft_extract_cmd(t_list **lst, int i)
{
	t_token		*token;
	t_command	*cmd;

	cmd = ft_set_cmd(lst);
	if (!cmd)
		return (NULL);
	while (*lst)
	{
		token = (t_token *)(*lst)->content;
		if (token->type == PIPE)
		{
			(*lst) = (*lst)->next;
			break ;
		}
		else if (token->type == WORD)
			cmd->args[++i] = ft_strdup(token->value);
		else
		{
			ft_lstadd_back(&cmd->redir, ft_lstnew(ft_redirnew(*lst)));
			(*lst) = (*lst)->next;
		}
		(*lst) = (*lst)->next;
	}
	return (cmd);
}

t_list	*ft_parser(t_list *lst)
{
	int			i;
	t_list		*lst_commands;
	t_command	*cmd;

	lst_commands = NULL;
	while (lst)
	{
		i = -1;
		cmd = ft_extract_cmd(&lst, i);
		if (cmd)
			ft_lstadd_back(&lst_commands, ft_lstnew(cmd));
	}
	return (lst_commands);
}
