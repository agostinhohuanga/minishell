/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_clean.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckulembe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/09 11:31:56 by ckulembe          #+#    #+#             */
/*   Updated: 2026/02/09 11:44:27 by ckulembe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "parse.h"

void	ft_redirclear(void *arg)
{
	t_redir	*redir;

	if (!arg)
		return ;
	redir = (t_redir *)arg;
	free(redir->value);
	free(redir);
}

void	ft_cmdclear(void *arg)
{
	int			i;
	t_command	*cmd;

	if (!arg)
		return ;
	cmd = (t_command *)arg;
	i = -1;
	while (cmd->args[++i])
		free(cmd->args[i]);
	ft_lstclear(&cmd->redir, ft_redirclear);
	free(cmd);
}
