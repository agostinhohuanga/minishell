/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printable.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckulembe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/09 10:38:29 by ckulembe          #+#    #+#             */
/*   Updated: 2026/02/09 11:23:48 by ckulembe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	ft_tokenprint(void *arg)
{
	t_token	*token;

	if (!arg)
		return ;
	token = (t_token *)arg;
	printf("%s\t%d\n", token->value, token->type);
	return ;
}

void	ft_redirprint(t_list *lst_redir)
{
	t_redir	*redir;

	printf("[");
	while (lst_redir)
	{
		redir = (t_redir *) lst_redir->content;
		printf("%s %s", value_token_type(redir->type), redir->value);
		if (!lst_redir->next)
			break ;
		printf(", ");
		lst_redir = lst_redir->next;
	}
	printf("]\n");
}

void	ft_commandprint(void *arg)
{
	int			i;
	int			length;
	t_command	*command;

	if (!arg)
		return ;
	command = (t_command *)arg;
	length = 0;
	while (command->args[length])
		length++;
	printf("Command:\n[");
	i = 0;
	while (i < length)
	{
		printf("%s", command->args[i]);
		if (i == length - 1)
			break ;
		printf(", ");
		i++;
	}
	printf("]\n");
	ft_redirprint(command->redir);
}
